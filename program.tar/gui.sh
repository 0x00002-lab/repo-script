#!/bin/bash

TMP_DIR="/tmp/run"
BASE_URL="https://github.com/0x00002-lab/repo-script/releases/download/repo/"

function download_and_run() {
    local filename="$1"
    mkdir -p "$TMP_DIR"
    local filepath="$TMP_DIR/$filename"
    wget -q -O "$filepath" "$BASE_URL$filename"
    chmod +x "$filepath"
    "$filepath"
}

function option1() {
    local filename
    filename=$(zenity --entry --title="Download Script" --text="Ingresa el nombre del script")
    [ -n "$filename" ] && download_and_run "$filename"
}

function option2() {
    local assets
    assets=$(curl -s https://api.github.com/repos/0x00002-lab/repo-script/releases/latest \
        | grep '"name":' \
        | grep -vE '\.zip|\.tar\.gz|\.tar\.bz2|\.tar\.xz' \
        | sed 's/.*"name": "\(.*\)".*/\1/')
    local selection
    selection=$(echo "$assets" | zenity --list --title="Select Script" --column="Scripts")
    [ -n "$selection" ] && download_and_run "$selection"
}

CHOICE=$(zenity --list --title="Repo Runner" --column="Option" \
    "Download & Run (nombre)" \
    "Fetch & Select Script")

case "$CHOICE" in
    "Download & Run (nombre)") option1 ;;
    "Fetch & Select Script") option2 ;;
esac
