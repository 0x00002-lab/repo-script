#!/bin/bash
TMP_DIR="/tmp/run"
BASE_URL="https://github.com/0x00002-lab/repo-script/releases/download/repo/"

mkdir -p "$TMP_DIR"

get_name() {
    local url="$1"
    local name
    name=$(curl -s "$url" | head -n5 | grep -m1 "^#NAME=" | cut -d= -f2)
    echo "${name:-$(basename "$url")}"
}

download_script() {
    local file="$1"
    local path="$TMP_DIR/$file"
    wget -q -O "$path" "$BASE_URL$file"
    chmod +x "$path"
    echo "$path"
}

option_2() {
    local urls assets names
    assets=$(curl -s https://api.github.com/repos/0x00002-lab/repo-script/releases/latest \
        | grep '"name":' \
        | grep -vE '\.zip|\.tar\.gz|\.tar\.bz2|\.tar\.xz' \
        | sed 's/.*"name": "\(.*\)".*/\1/')
    urls=()
    names=()
    while read -r file; do
        urls+=("$file")
        names+=("$(get_name "$BASE_URL$file")")
    done <<< "$assets"

    selected=$(zenity --list --checklist --multiple --column "Sel" --column "Script" \
        $(for i in "${!names[@]}"; do echo "FALSE" "${names[i]}"; done) \
        --height=400 --width=600 --title="Selecciona scripts")
    IFS="|" read -ra choices <<< "$selected"
    for choice in "${choices[@]}"; do
        for i in "${!names[@]}"; do
            if [[ "${names[i]}" == "$choice" ]]; then
                script_path=$(download_script "${urls[i]}")
                # Launch in a new Konsole and close after execution
                konsole -e bash -c "$script_path; exit" &
            fi
        done
    done
}

option_2
