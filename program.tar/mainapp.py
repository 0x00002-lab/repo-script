#!/usr/bin/env python3
import os
import subprocess
import sys
import requests
import locale

TMP_DIR = "/tmp/run"
GITHUB_BASE = "https://github.com/0x00002-lab/repo-script/releases/download/repo/"

lang = locale.getlocale()[0]
if lang and lang.startswith("es"):
    M = {
        "fetching": "Descargando disponible...",
        "no_assets": "No se encontraron scripts descargables.",
        "select_script": "Selecciona un script para descargar: ",
        "downloading": "Descargando {}..."
    }
else:
    M = {
        "fetching": "Fetching available releases...",
        "no_assets": "No downloadable scripts found.",
        "select_script": "Select a script to download: ",
        "downloading": "Downloading {}..."
    }

def detect_interpreter(path):
    try:
        with open(path, "r") as f:
            first_line = f.readline().strip()
            if first_line.startswith("#!"):
                return first_line[2:]
    except:
        pass
    if path.endswith(".sh"):
        return "bash"
    if path.endswith(".py"):
        return "python3"
    return None

def download_and_run(filename):
    os.makedirs(TMP_DIR, exist_ok=True)
    filepath = os.path.join(TMP_DIR, filename)
    url = GITHUB_BASE + filename
    print(M["downloading"].format(url))
    r = requests.get(url)
    if r.status_code != 200:
        print(M["no_assets"])
        return
    with open(filepath, "wb") as f:
        f.write(r.content)
    interp = detect_interpreter(filepath)
    os.chmod(filepath, 0o755)
    if interp:
        subprocess.run([interp, filepath])
    else:
        subprocess.run([filepath])

def option_2():
    print(M["fetching"])
    try:
        r = requests.get("https://api.github.com/repos/0x00002-lab/repo-script/releases/latest")
        data = r.json()
        assets = data.get("assets", [])
        if not assets:
            print(M["no_assets"])
            return
        scripts = [a for a in assets if not a['name'].endswith(('.zip', '.tar.gz', '.tar.bz2', '.tar.xz'))]
        for i, asset in enumerate(scripts, 1):
            print(f"{i}) {asset['name']}")
        choice = int(input(M["select_script"]))
        filename = scripts[choice-1]['name']
        download_and_run(filename)
    except:
        print(M["no_assets"])

def main():
    if len(sys.argv) > 1:
        download_and_run(sys.argv[1])
    else:
        option_2()

if __name__ == "__main__":
    main()
