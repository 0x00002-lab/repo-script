#!/usr/bin/env python3
import os
import subprocess
import sys
import requests
import re

TMP_DIR = "/tmp/run"
GITHUB_BASE = "https://github.com/0x00002-lab/repo-script/releases/download/repo/"

def get_name_from_script(path):
    try:
        r = requests.get(path)
        content = r.text.splitlines()
        for line in content[:5]:
            m = re.match(r"#NAME=(.+)", line)
            if m:
                return m.group(1)
    except:
        pass
    return os.path.basename(path)

def detect_interpreter(path):
    try:
        with open(path, "r") as f:
            line = f.readline().strip()
            if line.startswith("#!"):
                return line[2:]
    except:
        pass
    if path.endswith(".sh"):
        return "bash"
    if path.endswith(".py"):
        return "python3"
    return None

def download_and_run(filename):
    os.makedirs(TMP_DIR, exist_ok=True)
    filepath = os.path.join(TMP_DIR, filename)
    url = GITHUB_BASE + filename
    r = requests.get(url)
    if r.status_code != 200:
        print(f"Error downloading {filename}")
        return
    with open(filepath, "wb") as f:
        f.write(r.content)
    interp = detect_interpreter(filepath)
    os.chmod(filepath, 0o755)
    if interp:
        subprocess.run([interp, filepath])
    else:
        subprocess.run([filepath])

def option_2():
    r = requests.get("https://api.github.com/repos/0x00002-lab/repo-script/releases/latest")
    data = r.json()
    assets = data.get("assets", [])
    scripts = [a for a in assets if not a['name'].endswith(('.zip','.tar.gz','.tar.bz2','.tar.xz'))]
    display_names = [get_name_from_script(a['browser_download_url']) for a in scripts]
    for i, name in enumerate(display_names,1):
        print(f"{i}) {name}")
    choices = input("Selecciona scripts separados por coma: ").split(",")
    for c in choices:
        try:
            idx = int(c.strip()) - 1
            download_and_run(scripts[idx]['name'])
        except:
            continue

def main():
    if len(sys.argv) > 1:
        for filename in sys.argv[1:]:
            download_and_run(filename)
    else:
        option_2()

if __name__ == "__main__":
    main()
